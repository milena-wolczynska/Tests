# Ćwiczenie figures
1. Przejdź do klasy `SquareTest` włącz test i sprawdź czy przeszedł 
0. Dodać test testujący metodę obliczania obwodu.
1. Utwórz nową klase o nazwie` Rectangle`. Powinien przyjmować dwa parametry w konstruktorze `int a` i `int b`
5. Zaimplementuj brakujące metody, napisz testy.
6. Dodaj kolejne liczby w oparciu o kroki (1 - 3):
    * romb
    * trójkąt
    * kółko - możesz założyć, że π jest równe `3.14`
    * trapez
7. Nie martw się, jeśli zapomnisz o jakimś wzorze ze szkoły podstawowej. Pamiętaj, że w pracy bardzo często będziesz mógł, a nawet powinieneś korzystać z internetu :-)
