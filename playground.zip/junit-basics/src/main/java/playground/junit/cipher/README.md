### Szyf Cezara - szyf przesuwający 

Twoim zadaniem będzie napisane klasy reprezętującej
funkcjonalność szyfru Cezara.

Stworzymy dwie metody które będą 
szyfrowały oraz odszyfrowały podany ciąg
znaków. 

# Jak działa szyf przesuwający? 
Zastępuje każdą litere tekstu inną, przesuniętą
o stałą lub wybraną cyfrą. 

przesunięcie - 3

* A => D
* B => E

Deszyfrowanie polega na odwróceniu tej operacji :) 


Hints: 

* Storzyć tablice char reprezentująca litery alfabetu
* Zamienić tekst do szyfrowania na tablice char (toCharArray())
* Sprawdzić czy litera szyfrowanego tekstu jest w tablicy alfabetu
* Jeśli jest znaleźć jej index, i dodać do niego przesunięcie 
* Otrzymamy index z którego musimy pobrać nowa szafyrowana litere






