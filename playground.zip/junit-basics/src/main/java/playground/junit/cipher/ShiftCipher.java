package playground.junit.cipher;

public class ShiftCipher {

    public String encode(String text, int shift) {
        return null;
    }

    public String decode(String text, int shift) {
        return null;
    }
}