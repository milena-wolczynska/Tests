FizzBuzz to jedno z popularniejszych praktycznych zadań podczas technicznej rekrutacji na programistę.

Podaj liczbę i jeśli będzie podzielna przez: 

* trzy – wypisz „Fizz”,
* pięć – wypisz „Buzz”,
* trzy i pięć wypisz „FizzBuzz”.

