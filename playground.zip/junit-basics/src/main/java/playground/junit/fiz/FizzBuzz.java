package playground.junit.fiz;

public class FizzBuzz {
    public FizzBuzz() {
    }

    public String fizzBuzz(int num) {
       return null;
    }
}
